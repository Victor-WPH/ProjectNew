package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;


@Entity
public class Resources {
    @Id
    @GeneratedValue (strategy=GenerationType.AUTO)
    private int resource_id;

    @CreatedDate
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate time_created;

    @LastModifiedDate
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate last_updated;

    @OneToMany(mappedBy = "resources")
    Set<Resource_Details> resource_detailsSet = new HashSet<>();

    @OneToMany(mappedBy = "resources")
    Set<Project_Resources> project_resources = new HashSet<>();

    public Resources(int resource_id, LocalDate time_created, LocalDate last_updated) {
        this.resource_id = resource_id;
        this.time_created = time_created;
        this.last_updated = last_updated;
    }

    public Resources() {

    }

    public int getResource_id() {
        return resource_id;
    }

    public void setResource_id(int resource_id) {
        this.resource_id = resource_id;
    }

    public LocalDate getTime_created() {
        return time_created;
    }

    public void setTime_created(LocalDate time_created) {
        this.time_created = time_created;
    }

    public LocalDate getLast_updated() {
        return last_updated;
    }

    public void setLast_updated(LocalDate last_updated) {
        this.last_updated = last_updated;
    }
}

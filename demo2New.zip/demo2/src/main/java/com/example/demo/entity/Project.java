package com.example.demo.entity;

import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Project{
    @Id
    @GeneratedValue (strategy=GenerationType.AUTO)
    @Column(name = "project_id")
    private int project_id;

    @CreatedDate
    private LocalDate time_created;

    public String getProject_name() {
        return project_name;
    }

    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    @ManyToOne
    private User owner;

    private String project_name;



    @OneToMany(mappedBy = "project_columns")
    Set<Project_columns> set = new HashSet<>();

    @OneToMany(mappedBy = "project")
    Set<Project_Resources> project_resources = new HashSet<>();

    public Project(){
}
    public Project(int project_id, LocalDate time_created, User owner) {
        this.project_id = project_id;
        this.time_created = time_created;
        this.owner = owner;
    }

    public int getProject_id() {
        return project_id;
    }

    public void setProject_id(int project_id) {
        this.project_id = project_id;
    }

    public LocalDate getTime_created() {
        return time_created;
    }

    public void setTime_created(LocalDate time_created) {
        this.time_created = time_created;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }

    public Set<Project_columns> getSet() {
        return set;
    }

    public void setSet(Set<Project_columns> set) {
        this.set = set;
    }

    public Set<Project_Resources> getProject_resources() {
        return project_resources;
    }

    public void setProject_resources(Set<Project_Resources> project_resources) {
        this.project_resources = project_resources;
    }
}
package com.example.demo.entity;

import javax.persistence.*;

@Entity
public class Project_columns {
    @Id
    @GeneratedValue (strategy=GenerationType.AUTO)
    private int column_id;

    @Column
    private int project_id;

    @Column
    private String column_name;

    @Enumerated
    @Column
    private ColumnType type;

    @ManyToOne
    private Project_columns project_columns;

    public int getColumn_id() {
        return column_id;
    }

    public void setColumn_id(int column_id) {
        this.column_id = column_id;
    }

    public int getProject_id() {
        return project_id;
    }

    public void setProject_id(int project_id) {
        this.project_id = project_id;
    }

    public String getColumn_name() {
        return column_name;
    }

    public void setColumn_name(String column_name) {
        this.column_name = column_name;
    }

    public ColumnType getType() {
        return type;
    }

    public void setType(ColumnType type) {
        this.type = type;
    }

}

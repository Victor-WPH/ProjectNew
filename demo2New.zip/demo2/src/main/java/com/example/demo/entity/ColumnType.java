package com.example.demo.entity;

public enum ColumnType {
    NUMBER,TEXT,FORMULA
}

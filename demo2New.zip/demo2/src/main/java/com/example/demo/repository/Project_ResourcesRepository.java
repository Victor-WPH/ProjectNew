package com.example.demo.repository;

import com.example.demo.entity.Project_Resources;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Project_ResourcesRepository extends JpaRepository <Project_Resources, Integer> {
//    void deleteByProject_idAndRecord_id (Integer project_id, Integer resource_id);
//    public List<Project_Resources> findByProjectAndResource(Project project, Resources resources);
//    public Project_Resources findByProject(Project project);
}
